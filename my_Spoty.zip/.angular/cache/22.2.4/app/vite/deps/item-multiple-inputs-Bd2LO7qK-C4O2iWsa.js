import "./index-BpRUsN_W-Dyk8UFjA.js";
//#region node_modules/@ionic/core/dist/esm/item-multiple-inputs-Bd2LO7qK.js
/*!
* (C) Ionic http://ionicframework.com - MIT License
*/
/**
* `item-multiple-inputs` is toggled on the item after its form controls render,
* so a control whose focus styling depends on it needs to re-render when it flips.
*
* @internal
* @param el The form control whose closest `ion-item` should be observed.
* @param onChange Called whenever one of `classNames` is added or removed.
* @param classNames The item classes the caller's rendering depends on. A caller
* reading more than one must list them all, or changes to the rest are ignored.
* @returns The observer to disconnect in `disconnectedCallback`, or `undefined`
* if it could not be created.
*/
var createItemMultipleInputsObserver = (el, onChange, classNames = ["item-multiple-inputs"]) => {
	const item = el.closest("ion-item");
	if (!item || typeof MutationObserver === "undefined") return;
	const readClasses = () => classNames.map((name) => item.classList.contains(name)).join(",");
	let previousClasses = readClasses();
	const observer = new MutationObserver(() => {
		const currentClasses = readClasses();
		if (currentClasses !== previousClasses) {
			previousClasses = currentClasses;
			onChange();
		}
	});
	observer.observe(item, {
		attributes: true,
		attributeFilter: ["class"]
	});
	return observer;
};
//#endregion
export { createItemMultipleInputsObserver as t };
